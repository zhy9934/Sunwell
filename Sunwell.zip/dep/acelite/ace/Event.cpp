#include "ace/Event.h"

#if !defined (__ACE_INLINE__)
//#include "ace/Event.inl"
#endif /* __ACE_INLINE__ */

#include "ace/Log_Category.h"
#include "ace/Condition_Attributes.h"

ACE_BEGIN_VERSIONED_NAMESPACE_DECL



ACE_END_VERSIONED_NAMESPACE_DECL
