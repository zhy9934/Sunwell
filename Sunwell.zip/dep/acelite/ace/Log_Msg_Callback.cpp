#include "ace/Log_Msg_Callback.h"

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Log_Msg_Callback::ACE_Log_Msg_Callback (void)
{
}

ACE_Log_Msg_Callback::~ACE_Log_Msg_Callback (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
