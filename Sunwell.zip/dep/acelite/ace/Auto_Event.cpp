#include "ace/Auto_Event.h"

#if !defined (__ACE_INLINE__)
//#include "ace/Auto_Event.inl"
#endif /* __ACE_INLINE__ */

ACE_BEGIN_VERSIONED_NAMESPACE_DECL



ACE_END_VERSIONED_NAMESPACE_DECL
