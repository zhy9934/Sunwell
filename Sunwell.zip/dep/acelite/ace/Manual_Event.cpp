#include "ace/Manual_Event.h"

#if !defined (__ACE_INLINE__)
//#include "ace/Manual_Event.inl"
#endif /* __ACE_INLINE__ */

ACE_BEGIN_VERSIONED_NAMESPACE_DECL



ACE_END_VERSIONED_NAMESPACE_DECL
